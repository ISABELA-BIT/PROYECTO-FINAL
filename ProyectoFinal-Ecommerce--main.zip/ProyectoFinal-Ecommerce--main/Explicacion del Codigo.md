Explicacion del codigo

Portada: Esta construida por dos secciones. una en donde se encuantra el mun principal para al navegacion de la pagina. 
La otra seccion es solo para mostrar el apartado "mi carrito", en donde se ven los productos adquiridos

Productos: Muestra una tabla en donde estan los productos disponibles para al venta (Siete en total), expecificando su nombre, imagen, precio, etc.
Al darle al boton "Añadir al carrito" le pide la cantidad de elementos de dicho producto.

mi carrito: Muestra el listado de los productos que ha adquirido el consumidor (Junto con su cantidad). Al lado de cada producto, aparece la opcion "Eliminar", que borra el producto del carrito.
AL final habrá un boton "Confirmar compra", que lo dirigirá a la pagina "Formulario"

Formulario: Realiza un formulario en el que pide el nombre del cliente, su correo y un coentario del servicio

Sobre Nosotros: PAgina en donde se explpica quiene somos (EstudioMarket).

Contactos: Pagina en donde explica los medios de comunicacion de EstudioMarket.

Cada pagina tiene un enlace "Volver", que lo redirige al inicio de la pagina (Portada).

Para que se guarden los productos incluso cerrando el navegador, se hizo uso del "localStorage".

Aparte de los archivos .css que nos da Bootpstrap, Tambien se hizo un archio .css propio en el que se guardaron estilos propios.

